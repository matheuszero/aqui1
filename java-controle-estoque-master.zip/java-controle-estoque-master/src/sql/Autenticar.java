
package sql;

public interface Autenticar {
    
    public String gravar();
    public String consultar();
    public String excluir();
    public String editar();
}
